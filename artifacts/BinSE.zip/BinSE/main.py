# -*- coding: utf-8 -*-

import CompareTwoBinaries as CTB

import os
import sys
import subprocess
import argparse
import torch

from tqdm import tqdm
import numpy as np
import heapq
import math
from collections import OrderedDict
from libs import (
    S2VGraph,
    read_data_gen_one_list,
    read_pickle,
    read_pickle_a,
    ControlGraphEmbedding,
    load_model,
)
from models.graphcnn import GraphCNN
from GIN import extract_all_graph
from torch_geometric.data import Data
from torch.utils.data.dataloader import DataLoader as asmDataLoader
from torch_geometric.data import DataLoader
from BlockEmbedding.asmRoberta import asmRobertaModel
from utils.DataLoaders import DataCollatorForSimilarBlocks
from DeepDNN import Net, MyData
from Tokenizer.InstructionTokenizer import InstructionTokenizer
from torch.nn import functional as F


def main(argv=None):
    ORIG_CWD = CTB.LAUNCH_CWD

    ckpt = "FunctionEmbedding/model.bin"
    tokenizer_path = "Tokenizer/model_save/tokenizer.model"
    blkEmbedding = "./BlockEmbedding/"

    parser = argparse.ArgumentParser(description="Compare two binaries (BinSE 2026 pipeline).")
    parser.add_argument("--file1", type=str, default=None, help="binary 1 (needs .pkl/.cmp.dat/.fcg.dat sidecars; default: bundled base64 O0 testdata)")
    parser.add_argument("--file2", type=str, default=None, help="binary 2 (needs .pkl/.cmp.dat/.fcg.dat sidecars; default: bundled base64 O3 testdata)")
    parser.add_argument("--device", type=str, default="auto", help="cuda:N / cpu / auto (auto = cuda:0 if available else cpu)")
    parser.add_argument("--min-blk", dest="min_blk", type=int, default=3)
    parser.add_argument("--out-pairs", dest="out_pairs", type=str, default=None, help="also write the function pair list to this file, same one-pair-per-line format as stdout (path resolves against the launch CWD)")
    parser.add_argument("--ida", type=str, default=None, help="path to a mounted IDA Pro install (dir containing idat, or the idat binary itself); enables feature extraction. Also reads env IDA_PATH.")
    parser.add_argument("--extract", type=str, action="append", default=None, metavar="BINARY", help="run IDA+ExtractFeatures on BINARY to generate <BINARY>.pkl/.cmp.dat/.fcg.dat (repeatable). With no --file1/--file2 this is extract-only and the CLI exits after. During compare, sidecars missing for --file1/--file2 are auto-extracted when --ida is set.")
    args = parser.parse_args(argv)

    ida_dir = args.ida or os.environ.get("IDA_PATH") or None

    def _find_idat(path):
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
        if os.path.isdir(path):
            for name in ("idat", "idat64", "ida", "ida64"):
                p = os.path.join(path, name)
                if os.access(p, os.X_OK):
                    return p
            raise FileNotFoundError("--ida %r contains no executable idat/ida" % path)
        raise FileNotFoundError("--ida path %r does not exist" % path)

    def _stub_path():
        cand = os.path.join(CTB.SUB_DIR, "ida_extract", "run_extract.py")
        if os.path.exists(cand):
            return cand
        legacy = os.path.join(CTB.SUB_DIR, "ExtractFeatures", "ExtractFeatures.9.2.py")
        if os.path.exists(legacy):
            return legacy
        raise FileNotFoundError("extractor not installed; use the BinSE_extractor package")

    sidcar_exts = (".pkl", ".cmp.dat", ".fcg.dat")

    def _extract_one(idat, target):
        target = os.path.abspath(target)
        stub = _stub_path()
        sys.stderr.write("[binse] extracting %s (IDA headless, may take minutes) ...\n" % target)
        proc = subprocess.run([idat, "-A", "-S" + stub, target],
                              cwd=os.path.dirname(target),
                              capture_output=True, text=True, timeout=3600)
        missing = [target + e for e in sidcar_exts if not os.path.exists(target + e)]
        if missing:
            tail = "\n".join(((proc.stdout or "") + "\n" + (proc.stderr or "")).splitlines()[-25:])
            raise RuntimeError("IDA extraction failed for %s (rc=%s), missing: %s\n--- ida output tail ---\n%s"
                               % (target, proc.returncode, missing, tail))
        sys.stderr.write("[binse] wrote %s{.pkl,.cmp.dat,.fcg.dat}\n" % target)
        return target

    def _resolve(p):
        return p if os.path.isabs(p) else os.path.normpath(os.path.join(ORIG_CWD, p))

    file1 = _resolve(args.file1) if args.file1 else os.path.join(CTB.SUB_DIR, "testdata/clang-10_coreutils-8.30_O0/base64")
    file2 = _resolve(args.file2) if args.file2 else os.path.join(CTB.SUB_DIR, "testdata/clang-10_coreutils-8.30_O3/base64")

    if args.extract:
        if not ida_dir:
            raise SystemExit("--extract requires --ida (or env IDA_PATH): path to a mounted IDA Pro install")
        idat = _find_idat(ida_dir)
        for t in args.extract:
            _extract_one(idat, _resolve(t))
        if not (args.file1 or args.file2):
            return
    if ida_dir:
        idat = _find_idat(ida_dir)
        for f in (file1, file2):
            if not all(os.path.exists(f + e) for e in sidcar_exts):
                _extract_one(idat, f)

    if args.device == "auto":
        device = torch.device("cuda:0") if torch.cuda.is_available() else torch.device("cpu")
    else:
        device = torch.device(args.device)
    if device.type == "cpu":
        _orig_load = torch.load

        def _cpu_load(*a, **kw):
            kw.setdefault("map_location", "cpu")
            obj = _orig_load(*a, **kw)
            if isinstance(obj, torch.nn.Module):
                for _sub in obj.modules():
                    if isinstance(getattr(_sub, "device", None), torch.device) and _sub.device.type == "cuda":
                        _sub.device = torch.device("cpu")
            return obj

        torch.load = _cpu_load

    CTB.device = device
    CTB.dimension = 256
    CTB.MIN_BLK = args.min_blk

    def _no_extraction(binary_name):
        missing = [ext for ext in (".pkl", ".cmp.dat", ".fcg.dat")
                   if not os.path.exists(binary_name + ext)]
        raise FileNotFoundError(
            "missing pre-extracted feature sidecars for %r: %s -- mount a licensed "
            "IDA Pro 9.x install into the container and pass --ida <mount>, or extract "
            "beforehand: ida.exe -A -S ExtractFeatures/ExtractFeatures.9.2.py <binary>. "
            "This build ships no IDA itself." % (binary_name, ", ".join(missing)))

    CTB.get_idb_file = _no_extraction
    CTB.cmd64 = "ida"
    CTB.script = "ExtractFeatures/ExtractFeatures.9.2.py"

    CTB.CGE_model = load_model("CG_store/")
    CTB.CGE_model.eval()
    CTB.BlkEmbedding = CTB.BlockEmbedding(model_directory=blkEmbedding, tokenizer=tokenizer_path,
                                          device=device, batch_size=CTB.BLK_BATCH_SIZE)
    CTB.CfgEmbedding = CTB.ControlGraphEmbedding(ckpt, device=device)

    CTB.vprint("[+] device: %s | MIN_BLK: %d" % (device, CTB.MIN_BLK))
    CTB.vprint("[+] bin1: %s" % file1)
    CTB.vprint("[+] bin2: %s" % file2)
    BC = CTB.compare_binaries_with_sequences(file1, file2)

    pairs = sorted(BC.matched_1.items())
    for func1, func2 in pairs:
        print("%s\t%s" % (func1, func2))

    if args.out_pairs:
        out_path = args.out_pairs if os.path.isabs(args.out_pairs) else os.path.join(ORIG_CWD, args.out_pairs)
        with open(out_path, "w", encoding="utf-8") as f:
            for func1, func2 in pairs:
                f.write("%s\t%s\n" % (func1, func2))


if __name__ == "__main__":
    main()
