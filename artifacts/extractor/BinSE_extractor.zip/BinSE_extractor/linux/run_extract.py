# -*- coding: utf-8 -*-
# Usage: idat -A -S"<this file>" <binary>
# Writes <binary>.pkl / .cmp.dat / .fcg.dat next to the target.
# Needs CPython 3.11 (the interpreter IDA 9.x uses).
import os
import sys

_here = os.path.dirname(os.path.abspath(__file__))
if _here not in sys.path:
    sys.path.insert(0, _here)

try:
    import ExtractFeatures
except ImportError as e:
    sys.stderr.write(
        "[binse] extractor load failed: %r\n"
        "[binse] expected ExtractFeatures.cpython-311-* next to %s "
        "(IDA 9.x uses CPython 3.11)\n" % (e, __file__))
    import idc
    idc.qexit(2)
